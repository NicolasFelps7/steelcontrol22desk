$ErrorActionPreference = 'Stop'
$Script = Join-Path $PSScriptRoot 'steelcontrol-edge\INSTALAR_EDGE.ps1'
if (-not (Test-Path $Script)) { throw 'Arquivos do SteelControl Edge nao encontrados.' }
& $Script
if ($LASTEXITCODE -and $LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
